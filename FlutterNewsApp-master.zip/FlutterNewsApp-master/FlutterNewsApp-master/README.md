![Flutter news app theindianappguy](https://user-images.githubusercontent.com/55942632/81510826-7fccd680-9332-11ea-9e67-ad6268aadf35.png)


Installation

```
flutter pub get
```
Usage 

```
flutter run
```



