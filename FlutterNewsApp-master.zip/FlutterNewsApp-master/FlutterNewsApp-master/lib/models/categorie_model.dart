class CategorieModel {
  String imageAssetUrl;
  String categorieName;

}
